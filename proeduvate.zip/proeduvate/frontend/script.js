﻿const defaultStore = {
  students: {
    STU001: {
      password: "student123",
      section1: {
        verificationStatus: "Verified",
        verifiedBy: "R. Kumar",
        verificationDateTime: "2026-01-12T10:30",
        leaveCalendar: "Pongal - 2026-01-14\nDiwali - 2026-11-08",
        mentorFeedback: "2026-01-22: Good progress in UI tasks.\n2026-02-02: Strong ownership on dashboard polish.",
        performanceMetrics: "Task Completion: 88%\nCode Quality: 4/5"
      },
      section2: {
        internName: "Arun Prakash",
        internId: "STU001",
        departmentYear: "CSE - 3rd Year",
        internshipRole: "Frontend Intern",
        college: "ABC Engineering College",
        referralPerson: "Mr. Suresh",
        email: "arun.prakash@college.edu",
        phone: "+91 98765 43210",
        whatsappGroup: "https://chat.whatsapp.com/example",
        resume: "https://example.com/resume/stu001.pdf",
        profileDetails: "Hobby: Chess\nLocation: Chennai\nLinkedIn: https://linkedin.com/in/stu001\nGitHub: https://github.com/stu001\nDOB: 2004-04-14\nCertifications: JS Basics\nSkill set: HTML, CSS, JS\nPast Internship: Web Intern at XYZ (2 months), Tech stack: React"
      },
      section3: {
        organizationName: "ProEduvate",
        internshipType: "Academic",
        internshipMode: "Hybrid",
        duration: "6 months",
        yearCompletion: "2026",
        joiningDate: "2025-12-01",
        completionDate: "2026-05-31",
        domain: "Frontend Development",
        mentorName: "Ms. Priya N.",
        statusStage: "Active"
      },
      section4: {
        responsibilities: "Build and maintain frontend modules.",
        tasks: "2026-01-02 - Landing page redesign - https://github.com/example/task1\n2026-01-15 - Component library update",
        projects: "Project: Internship Tracker\nStart: 2026-01-01\nEffective: 2026-01-03\nActual Completion: 2026-01-25\nRating: 4/5",
        toolsTechnologies: "HTML, CSS, JavaScript, Figma",
        tasksAssigned: "24",
        tasksCompleted: "19",
        tasksPending: "5",
        recentActivity: "2026-02-03: Submitted dashboard v2\n2026-02-06: Fixed responsive bugs\n2026-02-09: Added timeline animation"
      },
      section5: {
        leaveDays: "2",
        approvedHolidays: "2",
        presentDays: "20",
        attendancePercentage: "90",
        attendanceStatus: "Great",
        totalWorkingDays: "24",
        leavesTaken: "2",
        leavesToCompensate: "0"
      },
      section6: {
        lorStatus: "Received",
        issuedBy: "CTO - ProEduvate",
        issueDate: "2026-02-01",
        downloadButtonLink: "https://example.com/lor/stu001.pdf"
      },
      section7: {
        certificateId: "CERT-STU001-2026",
        issueDate: "2026-02-05",
        status: "Issued",
        downloadCertificate: "https://example.com/certificate/stu001.pdf",
        qrCode: "https://example.com/certificate/stu001-qr.png",
        documents: "AL: https://example.com/al.pdf\nTC: https://example.com/tc.pdf\nOL: https://example.com/ol.pdf\nOTHERS: https://example.com/other.pdf"
      },
      section8: {
        referenceId: "REF-STU001-7781",
        dataSource: "Internal Internship Portal",
        disclaimer: "This record is generated for verification purposes only."
      }
    }
  }
};

const state = {
  userRole: null,
  selectedStudentId: null,
  store: loadStore()
};

const els = {
  loginView: document.getElementById("loginView"),
  dashboardView: document.getElementById("dashboardView"),
  loginForm: document.getElementById("loginForm"),
  role: document.getElementById("role"),
  username: document.getElementById("username"),
  password: document.getElementById("password"),
  loginError: document.getElementById("loginError"),
  studentIdLabel: document.getElementById("studentIdLabel"),
  welcomeTitle: document.getElementById("welcomeTitle"),
  roleInfo: document.getElementById("roleInfo"),
  logoutBtn: document.getElementById("logoutBtn"),
  roleBadge: document.getElementById("roleBadge"),
  studentPicker: document.getElementById("studentPicker"),
  studentPickerWrap: document.getElementById("studentPickerWrap"),
  summaryCards: document.getElementById("summaryCards"),
  companyLogo: document.getElementById("companyLogo"),
  logoFallback: document.getElementById("logoFallback")
};

let revealObserver = null;

setupLogoFallback();
setupRevealAnimations();

els.role.addEventListener("change", () => {
  const role = els.role.value;
  const isAdminLike = role === "admin" || role === "hr";
  els.studentIdLabel.childNodes[0].nodeValue = isAdminLike ? "Admin Username" : "Student ID";
  els.username.placeholder = isAdminLike ? role : "e.g. STU001";
});

els.loginForm.addEventListener("submit", handleLogin);
els.logoutBtn.addEventListener("click", logout);
els.studentPicker.addEventListener("change", (e) => {
  state.selectedStudentId = e.target.value;
  renderDashboard();
});

function loadStore() {
  const raw = localStorage.getItem("internPortalDataV2");
  if (!raw) {
    localStorage.setItem("internPortalDataV2", JSON.stringify(defaultStore));
    return structuredClone(defaultStore);
  }
  try {
    return JSON.parse(raw);
  } catch {
    localStorage.setItem("internPortalDataV2", JSON.stringify(defaultStore));
    return structuredClone(defaultStore);
  }
}

function persistStore() {
  localStorage.setItem("internPortalDataV2", JSON.stringify(state.store));
}

function handleLogin(e) {
  e.preventDefault();
  const role = els.role.value;
  const username = els.username.value.trim();
  const password = els.password.value;

  if (role === "admin") {
    if (username === "admin" && password === "admin123") {
      enterDashboard("admin");
      return;
    }
    showError("Invalid admin credentials.");
    return;
  }

  if (role === "hr") {
    if (username === "hr" && password === "hr123") {
      enterDashboard("hr");
      return;
    }
    showError("Invalid HR credentials.");
    return;
  }

  const student = state.store.students[username];
  if (!student || student.password !== password) {
    showError("Invalid student credentials.");
    return;
  }

  enterDashboard("student", username);
}

function showError(msg) {
  els.loginError.textContent = msg;
}

function enterDashboard(role, studentId = null) {
  state.userRole = role;
  state.selectedStudentId = studentId || Object.keys(state.store.students)[0] || null;
  els.loginError.textContent = "";
  els.loginView.classList.add("hidden");
  els.dashboardView.classList.remove("hidden");
  renderDashboard();
}

function logout() {
  state.userRole = null;
  state.selectedStudentId = null;
  els.loginForm.reset();
  els.role.value = "student";
  els.studentIdLabel.childNodes[0].nodeValue = "Student ID";
  els.username.placeholder = "e.g. STU001";
  els.dashboardView.classList.add("hidden");
  els.loginView.classList.remove("hidden");
}

function renderDashboard() {
  const studentId = state.selectedStudentId;
  const student = state.store.students[studentId];

  if (!student) {
    document.getElementById("metricsContainer").innerHTML = "<p class='error'>No student records found.</p>";
    return;
  }

  const roleLabel = state.userRole === "student" ? "Student" : state.userRole === "hr" ? "HR" : "Admin";
  els.welcomeTitle.textContent = state.userRole === "student" ? "Student Home" : "Admin Home";
  els.roleInfo.textContent = `${roleLabel} view • ${student.section2?.internName || studentId}`;
  els.roleBadge.textContent = roleLabel.toUpperCase();

  const isAdminLike = state.userRole === "admin" || state.userRole === "hr";
  if (isAdminLike) {
    els.studentPickerWrap.classList.remove("hidden");
    const options = Object.keys(state.store.students)
      .map((id) => `<option value="${id}" ${id === studentId ? "selected" : ""}>${id}</option>`)
      .join("");
    els.studentPicker.innerHTML = options;
  } else {
    els.studentPickerWrap.classList.add("hidden");
  }

  if (state.userRole === "admin") {
    renderAdminDashboard();
  } else if (state.userRole === "hr") {
    renderHRDashboard();
  }

  refreshReveals();
}

function renderAdminDashboard() {
  const students = state.store.students || {};
  const studentList = Object.entries(students);

  // Hide HR sections
  document.getElementById("hrSections").classList.add("hidden");
  document.getElementById("adminSections").classList.remove("hidden");

  // Render metrics
  renderMetrics(studentList);

  // Render intern management
  renderInternManagement(studentList);

  // Render monitoring
  renderMonitoring(studentList);

  // Render verification section
  renderVerificationSection();

  // Render activity feed
  renderActivityFeed(studentList);
}

function renderHRDashboard() {
  const students = state.store.students || {};
  const studentList = Object.entries(students);

  // Hide Admin sections
  document.getElementById("adminSections").classList.add("hidden");
  document.getElementById("hrSections").classList.remove("hidden");

  // Render metrics
  renderMetricsHR(studentList);

  // Render onboarding
  renderOnboarding();

  // Render performance tracking
  renderPerformanceTracking(studentList);

  // Render attendance/leave
  renderAttendanceLeave(studentList);
}

function renderMetrics(studentList) {
  const total = studentList.length;
  const verified = studentList.filter(([_, s]) => s.section1?.verificationStatus === "Verified").length;
  const pending = total - verified;
  const active = studentList.filter(([_, s]) => s.section3?.statusStage === "Active").length;

  const attendanceAvg = Math.round(
    studentList.reduce((sum, [_, s]) => sum + (parseNumber(s.section5?.attendancePercentage, 0)), 0) / Math.max(total, 1)
  );

  const performanceAvg = Math.round(
    studentList.reduce((sum, [_, s]) => sum + extractPercent(s.section1?.performanceMetrics, 0), 0) / Math.max(total, 1)
  );

  const metricsData = [
    { label: "Total Interns", value: total, change: "+0" },
    { label: "Verified", value: verified, change: "+0", positive: true },
    { label: "Pending", value: pending, change: "-0", positive: false },
    { label: "Active", value: active, change: "+0", positive: true },
    { label: "Attendance Avg", value: `${attendanceAvg}%`, change: "+1%" },
    { label: "Performance Avg", value: `${performanceAvg}%`, change: "+2%" }
  ];

  const html = metricsData
    .map(m => `
      <div class="metric-card">
        <div class="metric-label">${m.label}</div>
        <div class="metric-value">${m.value}</div>
        <div class="metric-change ${m.positive === false ? 'negative' : ''}">${m.change}</div>
      </div>
    `)
    .join("");

  document.getElementById("metricsContainer").innerHTML = html;
}

function renderMetricsHR(studentList) {
  const assigned = studentList.length;
  const interviews = Math.round(assigned * 0.6);
  const offers = Math.round(assigned * 0.8);
  const pending = Math.round(assigned * 0.2);

  const metricsData = [
    { label: "Assigned Interns", value: assigned, change: "+1" },
    { label: "Interviews", value: interviews, change: "+2", positive: true },
    { label: "Offers Issued", value: offers, change: "+1", positive: true },
    { label: "Pending", value: pending, change: "-1", positive: false }
  ];

  const html = metricsData
    .map(m => `
      <div class="metric-card">
        <div class="metric-label">${m.label}</div>
        <div class="metric-value">${m.value}</div>
        <div class="metric-change ${m.positive === false ? 'negative' : ''}">${m.change}</div>
      </div>
    `)
    .join("");

  document.getElementById("metricsContainer").innerHTML = html;
}

function renderInternManagement(studentList) {
  const rows = studentList
    .map(([id, student]) => {
      const status = student.section3?.statusStage || "Pending";
      const verified = student.section1?.verificationStatus === "Verified" ? "Verified" : "Pending";
      return `
        <tr>
          <td>${id}</td>
          <td>${student.section2?.internName || "-"}</td>
          <td>${student.section2?.internshipRole || "-"}</td>
          <td><span class="status-badge ${status.toLowerCase()}">${status}</span></td>
          <td><span class="status-badge ${verified.toLowerCase()}">${verified}</span></td>
          <td>
            <button class="btn btn-primary" onclick="onViewStudentDetails('${id}')">View Details</button>
            <button class="btn btn-secondary" onclick="alert('Edit ${id}')">Edit</button>
          </td>
        </tr>
      `;
    })
    .join("");

  document.getElementById("internTableBody").innerHTML = rows;
}

function renderMonitoring(studentList) {
  const avgTaskCompletion = Math.round(
    studentList.reduce((sum, [_, s]) => {
      const assigned = parseNumber(s.section4?.tasksAssigned, 0);
      const completed = parseNumber(s.section4?.tasksCompleted, 0);
      return sum + (assigned ? (completed / assigned) * 100 : 0);
    }, 0) / Math.max(studentList.length, 1)
  );

  const avgAttendance = Math.round(
    studentList.reduce((sum, [_, s]) => sum + parseNumber(s.section5?.attendancePercentage, 0), 0) / Math.max(studentList.length, 1)
  );

  document.getElementById("attendanceOverview").innerHTML = `
    <div style="display: grid; gap: 10px;">
      <div><strong>${avgAttendance}%</strong> average attendance</div>
      <div class="bar"><span style="--value: ${avgAttendance}"></span></div>
    </div>
  `;

  document.getElementById("performanceChart").innerHTML = `
    <div style="display: grid; gap: 10px;">
      <div><strong>${avgTaskCompletion}%</strong> tasks completed</div>
      <div class="bar"><span style="--value: ${avgTaskCompletion}"></span></div>
    </div>
  `;
}

function renderVerificationSection() {
  document.getElementById("verificationAdminSection").innerHTML = `
    <div class="section-header">
      <h3>Verification & Certification</h3>
    </div>
    <div class="verification-grid">
      <div class="verification-item">
        <h4>Letter of Recommendation</h4>
        <p style="color: #4f6b8f; margin: 0 0 10px; font-size: 0.9rem;">Generate and send LOR to interns</p>
        <button class="btn btn-primary">Generate LOR</button>
      </div>
      <div class="verification-item">
        <h4>Certificate Management</h4>
        <p style="color: #4f6b8f; margin: 0 0 10px; font-size: 0.9rem;">Approve and issue completion certificates</p>
        <button class="btn btn-primary">Approve Certificates</button>
      </div>
      <div class="verification-item">
        <h4>Digital Verification</h4>
        <p style="color: #4f6b8f; margin: 0 0 10px; font-size: 0.9rem;">Create digital verification stamps</p>
        <button class="btn btn-primary">Generate Stamp</button>
      </div>
    </div>
  `;
}

function renderActivityFeed(studentList) {
  const activities = [
    { type: "Verification", text: "STU001 profile verified by admin", time: "2 hours ago", icon: "✓" },
    { type: "Task", text: "Dashboard component completed", time: "4 hours ago", icon: "✓" },
    { type: "Attendance", text: "All interns marked present today", time: "6 hours ago", icon: "✓" },
    { type: "Certificate", text: "LOR issued to STU001", time: "1 day ago", icon: "📄" },
    { type: "System", text: "Daily report generated", time: "1 day ago", icon: "⚙️" }
  ];

  const feedHtml = activities
    .map(a => `
      <div class="activity-item">
        <div class="activity-item-header">
          <span>${a.icon} ${a.type}</span>
          <span class="activity-time">${a.time}</span>
        </div>
        <div class="activity-text">${a.text}</div>
      </div>
    `)
    .join("");

  document.getElementById("activityFeedSection").innerHTML = `
    <div class="section-header">
      <h3>Recent Activity Feed</h3>
    </div>
    <div class="activity-feed">
      ${feedHtml}
    </div>
  `;
}

function renderOnboarding() {
  // This is already rendered in HTML, just ensure form handlers are set up
  const form = document.getElementById("addInternForm");
  if (form && !form.dataset.handlerAttached) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("New intern added successfully!");
      form.reset();
    });
    form.dataset.handlerAttached = "true";
  }
}

function renderPerformanceTracking(studentList) {
  const cardsHtml = studentList
    .slice(0, 3)
    .map(([id, student]) => {
      const taskCompletion = Math.round(
        (parseNumber(student.section4?.tasksCompleted, 0) / Math.max(parseNumber(student.section4?.tasksAssigned, 1), 1)) * 100
      );
      const perfScore = extractPercent(student.section1?.performanceMetrics, 85);

      return `
        <div class="performance-card reveal">
          <h5>${student.section2?.internName || id}</h5>
          <div class="performance-stat">
            <span>Task Completion</span>
            <strong>${taskCompletion}%</strong>
          </div>
          <div class="performance-stat">
            <span>Performance</span>
            <strong>${perfScore}%</strong>
          </div>
          <div class="performance-stat">
            <span>Status</span>
            <strong>${student.section3?.statusStage || "Active"}</strong>
          </div>
        </div>
      `;
    })
    .join("");

  document.getElementById("performanceCardsContainer").innerHTML = cardsHtml;

  const feedbackForm = document.getElementById("feedbackForm");
  if (feedbackForm && !feedbackForm.dataset.handlerAttached) {
    const studentSelect = feedbackForm.querySelector("#feedbackStudent");
    const options = studentList
      .map(([id, s]) => `<option value="${id}">${id} - ${s.section2?.internName || ""}</option>`)
      .join("");
    studentSelect.innerHTML = `<option>Select Intern</option>${options}`;

    feedbackForm.addEventListener("submit", (e) => {
      e.preventDefault();
      alert("Feedback submitted successfully!");
      feedbackForm.reset();
    });
    feedbackForm.dataset.handlerAttached = "true";
  }
}

function renderAttendanceLeave(studentList) {
  const summary = studentList
    .slice(0, 3)
    .map(([id, student]) => {
      const attendance = parseNumber(student.section5?.attendancePercentage, 85);
      return `
        <div style="padding: 10px 0; border-bottom: 1px solid #d6e5ff;">
          <strong>${student.section2?.internName || id}</strong>: ${attendance}%
        </div>
      `;
    })
    .join("");

  document.getElementById("attendanceSummary").innerHTML = summary;
  document.getElementById("leaveRequestsList").innerHTML = `
    <div style="padding: 10px; background: rgba(242, 161, 46, 0.1); border-radius: 8px; color: #b76d00; font-size: 0.9rem;">
      3 pending leave requests from interns
    </div>
  `;
}



function buildViewModel(student) {
  const s1 = student.section1 || {};
  const s2 = student.section2 || {};
  const s3 = student.section3 || {};
  const s4 = student.section4 || {};
  const s5 = student.section5 || {};
  const s6 = student.section6 || {};
  const s7 = student.section7 || {};
  const s8 = student.section8 || {};

  const attendancePercent = parseNumber(s5.attendancePercentage, 88);
  const performanceScore = extractPercent(s1.performanceMetrics, 84);
  const taskAssigned = parseNumber(s4.tasksAssigned, 24);
  const taskCompleted = parseNumber(s4.tasksCompleted, 19);
  const taskPending = parseNumber(s4.tasksPending, Math.max(taskAssigned - taskCompleted, 0));
  const taskCompletion = taskAssigned ? Math.round((taskCompleted / taskAssigned) * 100) : 0;

  return {
    verificationStatus: s1.verificationStatus || "Not Verified",
    verifiedBy: s1.verifiedBy || "-",
    verificationDateTime: s1.verificationDateTime || "-",
    leaveCalendar: s1.leaveCalendar || "",
    mentorFeedback: s1.mentorFeedback || "",
    performanceMetrics: s1.performanceMetrics || "",
    internName: s2.internName || "Intern",
    internId: s2.internId || "-",
    department: s2.departmentYear || "-",
    internshipRole: s2.internshipRole || "-",
    college: s2.college || "-",
    email: s2.email || "intern@proeduvate.com",
    phone: s2.phone || "+91 90000 00000",
    domain: s3.domain || s2.internshipRole || "-",
    mentorName: s3.mentorName || "Mentor Assigned",
    startDate: s3.joiningDate || "-",
    endDate: s3.completionDate || "-",
    internshipType: s3.internshipType || "-",
    duration: s3.duration || "-",
    statusStage: s3.statusStage || "Active",
    tasksAssigned: taskAssigned,
    tasksCompleted: taskCompleted,
    tasksPending: taskPending,
    taskCompletion,
    recentActivity: s4.recentActivity || s4.tasks || "",
    attendancePercent,
    attendanceStatus: s5.attendanceStatus || "-",
    lorStatus: s6.lorStatus || "Not Received",
    lorIssuedBy: s6.issuedBy || "-",
    lorIssueDate: s6.issueDate || "-",
    lorDownload: s6.downloadButtonLink || "#",
    certificateStatus: s7.status || "Not Generated",
    certificateDate: s7.issueDate || "-",
    certificateDownload: s7.downloadCertificate || "#",
    referenceId: s8.referenceId || "-",
    dataSource: s8.dataSource || "-",
    disclaimer: s8.disclaimer || "Verification data is confidential.",
    attendancePercentString: `${attendancePercent}%`,
    performanceScore
  };
}

function renderSummaryCards(model) {
  const badgeClass = model.verificationStatus.toLowerCase().includes("verified") ? "verified" : "not-verified";
  els.summaryCards.innerHTML = `
    <article class="summary-card reveal">
      <h4>Verification</h4>
      <div class="summary-value">
        <span class="badge ${badgeClass}">${model.verificationStatus}</span>
      </div>
    </article>
    <article class="summary-card reveal">
      <h4>Internship Duration</h4>
      <div class="summary-value">${model.duration}</div>
      <div class="small-note">${formatDate(model.startDate)} → ${formatDate(model.endDate)}</div>
    </article>
    <article class="summary-card reveal">
      <h4>Attendance</h4>
      <div class="summary-value" style="display:flex; align-items:center; gap:12px;">
        <div class="ring" style="--percent:${model.attendancePercent};">${model.attendancePercent}%</div>
        <div>
          <div>${model.attendanceStatus}</div>
          <div class="small-note">Overall Attendance</div>
        </div>
      </div>
    </article>
    <article class="summary-card reveal">
      <h4>Performance Score</h4>
      <div class="summary-value">${model.performanceScore}%</div>
      <div class="bar" style="--value:${model.performanceScore};"><span></span></div>
    </article>
  `;
}

function renderIdentity(model) {
  const initials = model.internName
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  els.identitySection.innerHTML = `
    <h3>Intern Identity</h3>
    <div class="identity-layout">
      <div class="profile-avatar">${initials || "IN"}</div>
      <div class="section-grid">
        ${infoBlock("Name", model.internName)}
        ${infoBlock("Intern ID", model.internId)}
        ${infoBlock("Department", model.department)}
        ${infoBlock("College", model.college)}
        ${infoBlock("Email", model.email)}
        ${infoBlock("Phone", model.phone)}
      </div>
    </div>
  `;
}

function renderInternship(model) {
  const timeline = [
    { label: "Onboarding", active: model.statusStage === "Onboarding" },
    { label: "Active Internship", active: model.statusStage === "Active" },
    { label: "Completion", active: model.statusStage === "Completed" }
  ];

  els.internshipSection.innerHTML = `
    <h3>Internship Information</h3>
    <div class="section-grid">
      ${infoBlock("Domain", model.domain)}
      ${infoBlock("Mentor Name", model.mentorName)}
      ${infoBlock("Start Date", formatDate(model.startDate))}
      ${infoBlock("End Date", formatDate(model.endDate))}
      ${infoBlock("Internship Type", model.internshipType)}
      ${infoBlock("Role", model.internshipRole)}
    </div>
    <div class="section-grid" style="margin-top:12px;">
      <div class="info-block">
        <span>Status Timeline</span>
        <div class="timeline">
          ${timeline
      .map(
        (item) => `
            <div class="timeline-item ${item.active ? "active" : ""}">
              <div class="timeline-dot"></div>
              <div><span>${item.label}</span><div class="small-note">${item.active ? "Current stage" : "Upcoming"}</div></div>
            </div>`
      )
      .join("")}
        </div>
      </div>
    </div>
  `;
}

function renderWork(model) {
  const activity = splitLines(model.recentActivity);
  els.workSection.innerHTML = `
    <h3>Work & Task Summary</h3>
    <div class="section-grid">
      <div class="info-block">
        <span>Task Completion</span>
        <div class="summary-value">${model.taskCompletion}%</div>
        <div class="bar" style="--value:${model.taskCompletion};"><span></span></div>
      </div>
      <div class="task-grid">
        ${taskMetric("Total Tasks", model.tasksAssigned)}
        ${taskMetric("Completed", model.tasksCompleted)}
        ${taskMetric("Pending", model.tasksPending)}
      </div>
    </div>
    <div class="section-grid" style="margin-top:12px;">
      <div class="info-block">
        <span>Recent Task Activity</span>
        <div class="timeline-activity">
          ${activity
      .map(
        (line) => `
            <div class="activity-item">
              <div>${line}</div>
            </div>`
      )
      .join("")}
        </div>
      </div>
    </div>
  `;
}

function renderAttendance(model) {
  const leaveDates = parseLeaveCalendar(model.leaveCalendar);
  const calendar = buildCalendar(leaveDates);
  const feedbackItems = splitLines(model.mentorFeedback);

  els.attendanceSection.innerHTML = `
    <h3>Attendance & Leave</h3>
    <div class="section-grid">
      ${infoBlock("Attendance", model.attendancePercentString)}
      ${infoBlock("Status", model.attendanceStatus)}
      ${infoBlock("Leave Days", leaveDates.length.toString())}
    </div>
    <div class="section-grid" style="margin-top:12px;">
      <div class="info-block">
        <span>Leave Calendar</span>
        <div class="calendar">
          <div class="calendar-header">${calendar.title}</div>
          <div class="calendar-grid">
            ${calendar.labels.map((label) => `<div class="calendar-cell muted">${label}</div>`).join("")}
            ${calendar.cells
      .map((cell) => `<div class="calendar-cell ${cell.className}">${cell.label.replace(/\n/g, "<br>")}</div>`)
      .join("")}
          </div>
        </div>
      </div>
      <div class="info-block">
        <span>Mentor Feedback</span>
        <div class="feedback-grid">
          ${feedbackItems
      .map(
        (line) => `
            <div class="feedback-card">
              <div>${line}</div>
            </div>`
      )
      .join("")}
        </div>
      </div>
    </div>
  `;
}

function renderLor(model) {
  const lorBadge = model.lorStatus.toLowerCase().includes("received") ? "verified" : "not-verified";
  const certBadge = model.certificateStatus.toLowerCase().includes("issued") || model.certificateStatus.toLowerCase().includes("generated")
    ? "verified"
    : "not-verified";

  els.lorSection.innerHTML = `
    <h3>LOR & Certificate</h3>
    <div class="section-grid">
      <div class="info-block">
        <span>LOR Status</span>
        <div class="summary-value"><span class="badge ${lorBadge}">${model.lorStatus}</span></div>
        <div class="small-note">${model.lorIssuedBy} • ${formatDate(model.lorIssueDate)}</div>
      </div>
      <div class="info-block">
        <span>Certificate</span>
        <div class="summary-value"><span class="badge ${certBadge}">${model.certificateStatus}</span></div>
        <div class="small-note">${formatDate(model.certificateDate)}</div>
      </div>
      <div class="info-block">
        <span>Download</span>
        <div class="small-note">LOR & Certificate</div>
        <div style="margin-top:8px; display:flex; gap:8px; flex-wrap:wrap;">
          <a class="cta" href="${model.lorDownload}" target="_blank" rel="noreferrer">Download LOR</a>
          <a class="cta" href="${model.certificateDownload}" target="_blank" rel="noreferrer">Download Certificate</a>
        </div>
      </div>
    </div>
  `;
}

function renderVerification(model) {
  els.verificationSection.innerHTML = `
    <h3>Verification Footer</h3>
    <div class="footer-meta">
      ${infoBlock("Verified By", model.verifiedBy)}
      ${infoBlock("Verification Date", formatDateTime(model.verificationDateTime))}
      ${infoBlock("Digital Badge", model.verificationStatus)}
      ${infoBlock("Timestamp", new Date().toLocaleString())}
      ${infoBlock("Reference ID", model.referenceId)}
      ${infoBlock("Data Source", model.dataSource)}
    </div>
    <p class="small-note" style="margin-top:10px;">${model.disclaimer}</p>
  `;
}

function infoBlock(label, value) {
  return `
    <div class="info-block">
      <span>${label}</span>
      <div>${value || "-"}</div>
    </div>
  `;
}

function taskMetric(label, value) {
  return `
    <div class="task-metric">
      <div class="summary-value">${value}</div>
      <div class="small-note">${label}</div>
    </div>
  `;
}

function extractPercent(text, fallback) {
  const match = (text || "").match(/(\d{1,3})\s*%/);
  if (!match) return fallback;
  const num = Number(match[1]);
  return Number.isNaN(num) ? fallback : Math.min(Math.max(num, 0), 100);
}

function parseNumber(value, fallback) {
  const num = Number(value);
  return Number.isNaN(num) ? fallback : num;
}

function splitLines(text) {
  if (!text) return ["No activity yet."];
  return text.split("\n").map((line) => line.trim()).filter(Boolean);
}

function parseLeaveCalendar(text) {
  const entries = splitLines(text);
  return entries
    .map((line) => {
      const match = line.match(/(.+?)\s*-\s*(\d{4}-\d{2}-\d{2})/);
      if (!match) return null;
      return { label: match[1].trim(), date: match[2] };
    })
    .filter(Boolean);
}

function buildCalendar(leaves) {
  const fallbackDate = "2026-01-01";
  const baseDate = leaves[0]?.date || fallbackDate;
  const dateObj = new Date(`${baseDate}T00:00:00`);
  const year = dateObj.getFullYear();
  const month = dateObj.getMonth();
  const monthLabel = dateObj.toLocaleString("default", { month: "long", year: "numeric" });
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const startDay = firstDay.getDay();
  const totalDays = lastDay.getDate();
  const labels = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const leaveSet = new Map();
  leaves.forEach((leave) => leaveSet.set(leave.date, leave.label));

  const cells = [];
  for (let i = 0; i < startDay; i += 1) {
    cells.push({ label: "", className: "muted" });
  }
  for (let day = 1; day <= totalDays; day += 1) {
    const dateStr = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const leaveLabel = leaveSet.get(dateStr);
    cells.push({
      label: leaveLabel ? `${day}\n${leaveLabel}` : day.toString(),
      className: leaveLabel ? "leave" : ""
    });
  }
  return { title: monthLabel, labels, cells };
}

function formatDate(value) {
  if (!value || value === "-") return value;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleDateString();
}

function formatDateTime(value) {
  if (!value || value === "-") return value;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function setupLogoFallback() {
  const logo = els.companyLogo;
  const fallback = els.logoFallback;
  if (!logo) return;

  const candidates = [
    "assets/company-logo.png",
    "assets/company-logo.jpg",
    "assets/company-logo.jpeg",
    "assets/company-logo.webp",
    "assets/logo.png",
    "assets/logo.jpg",
    "assets/logo.jpeg",
    "assets/logo.webp"
  ];

  let idx = 0;
  logo.src = candidates[idx];

  logo.addEventListener("error", () => {
    idx += 1;
    if (idx < candidates.length) {
      logo.src = candidates[idx];
      return;
    }
    logo.classList.add("hidden");
    if (fallback) fallback.classList.remove("hidden");
  });

  logo.addEventListener("load", () => {
    logo.classList.remove("hidden");
    if (fallback) fallback.classList.add("hidden");
  });
}

function setupRevealAnimations() {
  revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("show");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12 }
  );

  document.querySelectorAll(".reveal").forEach((el) => {
    if (!el.dataset.revealBound) {
      el.dataset.revealBound = "true";
      revealObserver.observe(el);
    }
  });
}

function refreshReveals() {
  document.querySelectorAll(".reveal").forEach((el) => {
    if (revealObserver && !el.dataset.revealBound) {
      el.dataset.revealBound = "true";
      revealObserver.observe(el);
    }
  });
}

// Student Detail View Functions
function onViewStudentDetails(studentId) {
  const student = state.store.students[studentId];
  if (!student) return;

  const detailSection = document.getElementById("studentDetailSection");
  const detailContent = document.getElementById("studentDetailContent");

  state.selectedStudentId = studentId;

  const s2 = student.section2 || {};
  const s3 = student.section3 || {};
  const s4 = student.section4 || {};
  const s5 = student.section5 || {};
  const s6 = student.section6 || {};
  const s7 = student.section7 || {};

  const html = `
    <div class="student-detail-grid">
      <!-- Personal Information -->
      <div class="detail-card">
        <h4>Personal Information</h4>
        <div class="detail-row">
          <span class="label">Name</span>
          <span class="value">${s2.internName || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Email</span>
          <span class="value">${s2.email || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Phone</span>
          <span class="value">${s2.phone || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">College</span>
          <span class="value">${s2.college || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Department/Year</span>
          <span class="value">${s2.departmentYear || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Date of Birth</span>
          <span class="value">${extractProfileField(s2.profileDetails, "DOB") || "-"}</span>
        </div>
      </div>

      <!-- Internship Details -->
      <div class="detail-card">
        <h4>Internship Details</h4>
        <div class="detail-row">
          <span class="label">Joining Date</span>
          <span class="value">${s3.joiningDate || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Completion Date</span>
          <span class="value">${s3.completionDate || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Mode</span>
          <span class="value">${s3.internshipMode || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Duration</span>
          <span class="value">${s3.duration || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Role</span>
          <span class="value">${s2.internshipRole || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Domain</span>
          <span class="value">${s3.domain || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Status</span>
          <span class="value badge-status">${s3.statusStage || "-"}</span>
        </div>
      </div>

      <!-- Contact Links -->
      <div class="detail-card">
        <h4>Contact & Links</h4>
        <div class="detail-row">
          <span class="label">Referral Person</span>
          <span class="value">${s2.referralPerson || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">WhatsApp Group</span>
          <span class="value">
            ${s2.whatsappGroup ? `<a href="${s2.whatsappGroup}" target="_blank" class="link">Join Group</a>` : "-"}
          </span>
        </div>
        <div class="detail-row">
          <span class="label">Resume</span>
          <span class="value">
            ${s2.resume ? `<a href="${s2.resume}" target="_blank" class="link">Download</a>` : "-"}
          </span>
        </div>
        <div class="detail-row">
          <span class="label">LinkedIn</span>
          <span class="value">
            ${extractProfileLink(s2.profileDetails, "LinkedIn") ? `<a href="${extractProfileLink(s2.profileDetails, "LinkedIn")}" target="_blank" class="link">Profile</a>` : "-"}
          </span>
        </div>
        <div class="detail-row">
          <span class="label">GitHub</span>
          <span class="value">
            ${extractProfileLink(s2.profileDetails, "GitHub") ? `<a href="${extractProfileLink(s2.profileDetails, "GitHub")}" target="_blank" class="link">Profile</a>` : "-"}
          </span>
        </div>
      </div>

      <!-- Profile Details -->
      <div class="detail-card">
        <h4>Personal Profile</h4>
        <div class="detail-row">
          <span class="label">Hobby</span>
          <span class="value">${extractProfileField(s2.profileDetails, "Hobby") || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Location</span>
          <span class="value">${extractProfileField(s2.profileDetails, "Location") || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Certifications</span>
          <span class="value">${extractProfileField(s2.profileDetails, "Certifications") || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Skill Set</span>
          <span class="value">${extractProfileField(s2.profileDetails, "Skill set") || "-"}</span>
        </div>
      </div>

      <!-- Past Internship -->
      <div class="detail-card">
        <h4>Past Internship</h4>
        <div class="detail-row">
          <span class="label">Details</span>
          <span class="value">${extractProfileField(s2.profileDetails, "Past Internship") || "-"}</span>
        </div>
      </div>

      <!-- Work & Projects -->
      <div class="detail-card">
        <h4>Projects & Work</h4>
        <div class="detail-row">
          <span class="label">Tools & Technologies</span>
          <span class="value">${s4.toolsTechnologies || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Projects</span>
          <span class="value" style="white-space: pre-wrap;">${s4.projects ? formatMultiline(s4.projects) : "-"}</span>
        </div>
      </div>

      <!-- Certificate -->
      <div class="detail-card">
        <h4>Certificate</h4>
        <div class="detail-row">
          <span class="label">Certificate ID</span>
          <span class="value">${s7.certificateId || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Issue Date</span>
          <span class="value">${s7.issueDate || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Status</span>
          <span class="value badge-status">${s7.status || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Download</span>
          <span class="value">
            ${s7.downloadCertificate ? `<a href="${s7.downloadCertificate}" target="_blank" class="link">Download Certificate</a>` : "-"}
          </span>
        </div>
      </div>

      <!-- Documents -->
      <div class="detail-card">
        <h4>Documents</h4>
        ${renderDocuments(s7.documents)}
      </div>

      <!-- LOR -->
      <div class="detail-card">
        <h4>Letter of Recommendation</h4>
        <div class="detail-row">
          <span class="label">Status</span>
          <span class="value badge-status">${s6.lorStatus || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Issued By</span>
          <span class="value">${s6.issuedBy || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Issue Date</span>
          <span class="value">${s6.issueDate || "-"}</span>
        </div>
        <div class="detail-row">
          <span class="label">Download</span>
          <span class="value">
            ${s6.downloadButtonLink ? `<a href="${s6.downloadButtonLink}" target="_blank" class="link">Download LOR</a>` : "-"}
          </span>
        </div>
      </div>
    </div>
  `;

  detailContent.innerHTML = html;
  detailSection.classList.remove("hidden");
  detailSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

function closeStudentDetail() {
  document.getElementById("studentDetailSection").classList.add("hidden");
}

function extractProfileField(profileDetails, fieldName) {
  if (!profileDetails) return null;
  const lines = profileDetails.split("\n").map(l => l.trim());
  for (const line of lines) {
    if (line.startsWith(fieldName + ":")) {
      return line.substring(fieldName.length + 1).trim();
    }
  }
  return null;
}

function extractProfileLink(profileDetails, linkName) {
  if (!profileDetails) return null;
  const lines = profileDetails.split("\n").map(l => l.trim());
  for (const line of lines) {
    if (line.startsWith(linkName + ":")) {
      const url = line.substring(linkName.length + 1).trim();
      return url.startsWith("http") ? url : null;
    }
  }
  return null;
}

function formatMultiline(text) {
  if (!text) return "-";
  return text.split("\n").map(l => l.trim()).filter(Boolean).join("\n");
}

function renderDocuments(documentsStr) {
  if (!documentsStr) {
    return '<div class="detail-row"><span class="value">No documents available</span></div>';
  }

  const docs = documentsStr.split("\n").map(d => d.trim()).filter(Boolean);
  return docs.map(doc => {
    const [name, url] = doc.split(":").map(s => s.trim());
    return `
      <div class="detail-row">
        <span class="label">${name || "Document"}</span>
        <span class="value">
          ${url ? `<a href="${url}" target="_blank" class="link">Download</a>` : "-"}
        </span>
      </div>
    `;
  }).join("");
}

